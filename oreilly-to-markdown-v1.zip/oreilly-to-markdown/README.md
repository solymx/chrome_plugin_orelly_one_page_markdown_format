# O'Reilly → Markdown（Chrome 擴充功能 v1.0.0）

把你**目前正在 learning.oreilly.com 閱讀的那一頁**（書本章節、文章）轉成乾淨的 Markdown，方便自己閱讀、做筆記或丟給翻譯工具翻成繁體中文。

- 只處理「目前開著的單一頁面」。**不會**自動翻頁、不會批次抓取、不會繞過 DRM 或付費牆。
- 不連到任何外部伺服器、沒有任何追蹤或分析（analytics）。
- 所有函式庫（Turndown、turndown-plugin-gfm、fflate）都已經打包在 `vendor/` 資料夾內，沒有 CDN、沒有遠端程式碼（符合 Manifest V3 規定）。

---

## 功能

| 功能 | 說明 |
| --- | --- |
| 複製到剪貼簿 (Copy) | 轉成 Markdown 後直接複製 |
| 下載 .md (Download .md) | 存成 `章節標題.md` |
| 下載 .md + 圖片 (zip) | 把內容裡的圖片一起下載，打包成 `章節標題.zip`（內含 `章節標題.md` + `images/01-xxx.png`…），Markdown 內的圖片連結會改成相對路徑 `images/…` |
| 除錯：複製 HTML 片段 | 抓錯內容時，把頁面結構資訊複製下來貼回給我們調整 |
| 右鍵選單 | 在 learning.oreilly.com 頁面上按右鍵 →「O'Reilly → Markdown」→ 同樣四個功能 |

轉換時會保留：

- 標題層級（`#`、`##`、`###`…；O'Reilly 的 HTMLBook 格式每節都用 `<h1>`，會依 `chapter / sect1 / sect2` 自動修正層級）
- 段落、**粗體**、*斜體*、`行內程式碼`
- 有序／無序／多層巢狀清單
- 表格（GFM 格式，含表格標題；儲存格中的 `|` 會跳脫、多段落以 `<br>` 合併）
- 程式碼區塊，含語言標籤（從 `language-xxx`、`lang-xxx`、`data-code-language`、`data-type="programlisting"` 等判斷），程式碼中的註解編號 (callout) 會變成 `(1)`
- 連結（全部轉成絕對網址）、圖片（保留原始絕對網址與 alt 文字，支援 lazy-load 的 `data-src`）
- Note / Tip / Warning / Caution / Sidebar 提示框 → 引言區塊 `> [!NOTE]`（GitHub、Obsidian 會顯示成彩色提示框）
- 圖說（Figure caption）→ 圖片下方的斜體文字
- 註腳 → Markdown 註腳 `[^1]` / `[^1]: ...`

檔案開頭會加上 YAML front matter：

```yaml
---
title: "Chapter 3. Securing the Widget Pipeline"
page_title: "3. Securing the Widget Pipeline - Practical Widget Security [Book]"
source: "https://learning.oreilly.com/library/view/.../ch03.html"
extracted_at: "2026-11-20T05:37:56.575Z"
generator: "oreilly-to-markdown v1.0.0"
---
```

檔名 = 章節標題（保留中文、日文等 Unicode 字元，移除 `\ / : * ? " < > |` 等不合法字元，最長 120 字）。

---

## 安裝步驟

1. 解壓縮 `oreilly-to-markdown-v1.zip`，會得到 `oreilly-to-markdown` 資料夾。
2. 在 Chrome 網址列輸入 `chrome://extensions` 並按 Enter。
3. 打開右上角的 **「開發人員模式」**。
4. 按左上角 **「載入未封裝項目」**。
5. 選擇剛剛解壓縮出來的 **`oreilly-to-markdown` 資料夾**（裡面要直接看得到 `manifest.json`）。
6. 建議按工具列的拼圖圖示 🧩，把「O'Reilly to Markdown」釘選到工具列。

> 需要 Chrome 116 以上版本（Edge、Brave 等 Chromium 瀏覽器也可以）。

---

## 使用方式

**方法一：工具列按鈕**

1. 打開 learning.oreilly.com 的某一章或某篇文章，等內容完全載入。
2. 按工具列上的紅色「MD」圖示。
3. 選擇「複製到剪貼簿」、「下載 .md」或「下載 .md + 圖片 (zip)」。

**方法二：右鍵選單**

在 learning.oreilly.com 頁面任意處按右鍵 →「O'Reilly → Markdown」→ 選擇功能。右下角會出現綠色提示訊息。

> 如果右鍵「複製」失敗（少數情況瀏覽器會擋住剪貼簿），請改用工具列按鈕的「複製」，那個路徑最穩定。

**翻譯小技巧**：下載 .md 後丟給翻譯工具（例如 DeepL、ChatGPT）時，可以要求「保留 Markdown 格式與程式碼區塊不要翻譯」。

---

## 權限說明

| 權限 | 為什麼需要 |
| --- | --- |
| `activeTab` | 只有在**你按下按鈕或右鍵選單**的那一刻，才暫時取得目前分頁的存取權。不會在背景讀取任何網頁。 |
| `scripting` | 在你按下按鈕時，把轉換程式注入目前分頁（只在 `https://learning.oreilly.com/*` 才會執行，其他網站會顯示提示訊息）。 |
| `clipboardWrite` | 把 Markdown 寫入剪貼簿。 |
| `downloads` | 下載 `.md` / `.zip` 檔案。 |
| `contextMenus` | **（唯一額外加入的權限）** 建立右鍵選單。選單只會出現在 learning.oreilly.com 的頁面上。 |

- **沒有** `host_permissions`、**沒有**「讀取所有網站資料」權限、沒有常駐的 content script。
- 擴充功能頁面的 CSP 設定了 `connect-src 'none'`，擴充功能本身無法連線到任何伺服器。
- 唯一的網路行為：當你選「下載 .md + 圖片 (zip)」時，會在 O'Reilly 頁面裡用**你自己目前的登入狀態**下載「該章節內容中的圖片」（就跟瀏覽器顯示這些圖片一樣）。不會傳送任何資料出去。

---

## 抓錯內容怎麼辦？（傳 HTML 片段回來調整）

O'Reilly 的網頁結構我們無法登入實測，所以選擇器是「猜測 + 備援」設計。如果轉出來的內容不對（抓到目錄、少了一段、多了按鈕文字…）：

1. 在出問題的頁面上，按工具列圖示 → 最下方的 **「除錯：複製內容區塊 HTML 片段」**（或右鍵選單 → 除錯）。
2. 剪貼簿內會有：網址、選到哪個區塊、每個選擇器的嘗試結果、頁面結構大綱、選到區塊的前 15000 字元 HTML。
3. 直接貼回給我們，並說明哪裡不對（例如「少了最後一節」、「多了側邊欄」）。

> 片段中會包含部分章節文字，只用於調整選擇器。若介意，可以只貼「page outline」那一段。

**自己動手調整**：所有選擇器都在 `src/config.js` 最上方（有中文註解）。

- `contentSelectors`：主要內容區塊的選擇器清單，由上往下嘗試。
- `removeSelectors`：要從內容中移除的雜訊（按鈕、工具列、註記 UI…）。
- `admonitionStyle`：提示框格式，`'github'`（`> [!NOTE]`）或 `'plain'`（`> **Note**`）。

改完後到 `chrome://extensions` 按擴充功能卡片上的「重新載入 ↻」。

---

## 已知限制

- **DOM 只用一個真實頁面驗證過**：2026-11 用一份 Apress（Springer 格式）書籍章節的實際頁面測試，內容容器為 `#sbo-rt-content`，文字保留率約 99.9%。O'Reilly 自家（HTMLBook 格式）書籍、影片頁、文章頁尚未用真實頁面驗證；網站改版後選擇器也可能失效。找不到時會自動用「文字量最大的區塊」判斷。
- **Apress / Springer 書籍的表格放在另一個頁面**（`Table_xx.xhtml`），章節頁裡只有表格標題和連結。轉換結果會保留標題並附上「表格內容在另一頁」的連結；需要表格內容時請打開那一頁再轉一次。
- 若閱讀器把內容放在**跨網域 iframe** 或 **Shadow DOM** 中，目前抓不到（同網域 iframe 可以）。
- 只轉換**已經顯示在頁面上**的內容；若網站採「捲動才載入」，請先捲到底再轉換。
- 數學公式（MathML / MathJax）只會保留文字，不會轉成 LaTeX。
- 有合併儲存格（colspan / rowspan）或巢狀表格的複雜表格，GFM 表格無法完整表達，可能會跑版。
- 影片、互動式內容（Jupyter、測驗）不會轉換。
- 圖片打包：如果圖片放在其他網域（CDN）且不允許跨來源存取，會下載失敗；失敗的圖片保留原始網址，並列在 `.md` 最後的註解中。
- 非常大的章節（圖片很多、總計數十 MB）打包時可能需要幾秒鐘。
- 請遵守 O'Reilly 的服務條款：轉出的內容僅供個人學習使用，請勿散布。

---

## 檔案結構

```
oreilly-to-markdown/
├── manifest.json          # MV3 設定
├── README.md
├── icons/                 # 工具列圖示
├── popup/                 # 工具列按鈕的小視窗
│   ├── popup.html / popup.css / popup.js
├── src/
│   ├── config.js          # ★ 使用者可調整的選擇器設定
│   ├── converter.js       # 擷取內容 + 轉 Markdown + 打包 zip（注入頁面執行）
│   ├── inject.js          # popup 與 background 共用：注入、下載
│   └── background.js      # 右鍵選單
└── vendor/                # 本地打包的函式庫（未修改）
    ├── turndown.js                (turndown 7.2.5, MIT)
    ├── turndown-plugin-gfm.js     (turndown-plugin-gfm 1.0.2, MIT)
    ├── fflate.min.js              (fflate 0.8.3, MIT)
    └── LICENSE-*.txt / VERSIONS.txt
```
