/*
 * O'Reilly to Markdown — page-side logic (injected on demand via chrome.scripting).
 * Runs in the extension's isolated world of the CURRENT tab only.
 * Depends on (injected before this file): vendor/turndown.js, vendor/turndown-plugin-gfm.js,
 * vendor/fflate.min.js, src/config.js
 *
 * No network requests except: when the user explicitly chooses "Download .md + images (zip)",
 * the images inside the extracted content are fetched from the page's own context
 * (same session the user is already reading with). Nothing is sent anywhere.
 */
(function () {
  'use strict';
  var VERSION = '1.0.0';
  var BLOCK_SEL = 'p, pre, li, h1, h2, h3, h4, h5, h6, td, th, blockquote, dd, dt, figcaption';
  var NOISE_ANCESTOR_SEL = 'nav, header[role="banner"], footer, aside:not([data-type]), [role="navigation"], [role="complementary"], [role="banner"], [role="contentinfo"]';

  function cfg() { return globalThis.__OMD_CONFIG || {}; }
  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
  // textContent, but with a space between block/inline elements ("Fig. 3-1" + "Caption" → "Fig. 3-1 Caption")
  function spacedText(el) {
    var parts = [];
    (function walk(n) { Array.prototype.forEach.call(n.childNodes, function (c) { if (c.nodeType === 3) parts.push(c.nodeValue); else if (c.nodeType === 1) { parts.push(' '); walk(c); parts.push(' '); } }); })(el);
    return norm(parts.join('')).replace(/\s+([.,:;!?)])/g, '$1');
  }
  function textLen(el) { return norm(el && el.textContent).length; }
  function safeQueryAll(root, sel) { try { return Array.prototype.slice.call(root.querySelectorAll(sel)); } catch (e) { return null; } }

  /* ------------------------------------------------------------------ *
   * 1. Find the main content container
   * ------------------------------------------------------------------ */
  function collectDocs(doc) {
    var docs = [doc];
    if (cfg().searchSameOriginIframes !== false) {
      safeQueryAll(doc, 'iframe, frame').forEach(function (f) {
        try { if (f.contentDocument && f.contentDocument.body) docs.push(f.contentDocument); } catch (e) { /* cross-origin: skip */ }
      });
    }
    return docs;
  }

  function trySelectors(doc, log) {
    var sels = cfg().contentSelectors || [];
    var min = cfg().minTextLength || 200;
    for (var i = 0; i < sels.length; i++) {
      var els = safeQueryAll(doc, sels[i]);
      if (els === null) { log.push({ selector: sels[i], error: 'invalid selector' }); continue; }
      var best = null, bestLen = 0;
      els.forEach(function (el) { var l = textLen(el); if (l > bestLen) { best = el; bestLen = l; } });
      log.push({ selector: sels[i], matches: els.length, bestTextLength: bestLen, frame: doc === document ? 'top' : 'iframe' });
      if (best && bestLen >= min) return { el: best, method: 'selector', selector: sels[i], textLength: bestLen };
    }
    return null;
  }

  // Heuristic: deepest element that still contains >= 85% of the page's "readable block" text.
  function heuristic(doc) {
    var body = doc.body; if (!body) return null;
    var sums = new Map();
    safeQueryAll(body, BLOCK_SEL).forEach(function (b) {
      if (b.querySelector(BLOCK_SEL) && b.tagName !== 'PRE' && b.tagName !== 'LI') return; // leaf blocks only (approx.)
      if (b.closest(NOISE_ANCESTOR_SEL)) return;
      var len = textLen(b); if (!len) return;
      var linkLen = 0; safeQueryAll(b, 'a').forEach(function (a) { linkLen += textLen(a); });
      if (b.tagName !== 'PRE' && linkLen / len > 0.5) return; // link lists (TOC etc.)
      for (var n = b.parentElement; n; n = n.parentElement) { sums.set(n, (sums.get(n) || 0) + len); if (n === body) break; }
    });
    var total = sums.get(body) || 0; if (!total) return null;
    var cur = body;
    for (;;) {
      var next = null, nextSum = 0;
      Array.prototype.forEach.call(cur.children, function (c) { var s = sums.get(c) || 0; if (s > nextSum) { next = c; nextSum = s; } });
      if (next && nextSum >= total * 0.85) cur = next; else break;
    }
    return { el: cur, method: 'heuristic', selector: describe(cur), textLength: textLen(cur) };
  }

  function findContainer(doc) {
    doc = doc || document;
    var log = [], docs = collectDocs(doc), r = null;
    for (var i = 0; i < docs.length && !r; i++) r = trySelectors(docs[i], log);
    if (!r) {
      var best = null;
      docs.forEach(function (d) { var h = heuristic(d); if (h && (!best || h.textLength > best.textLength)) best = h; });
      r = best;
    }
    if (r) r.log = log;
    return r ? r : { el: null, log: log };
  }

  function describe(el) {
    if (!el || !el.tagName) return String(el);
    var s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    if (el.classList && el.classList.length) s += '.' + Array.prototype.slice.call(el.classList, 0, 4).join('.');
    ['data-testid', 'data-type', 'role'].forEach(function (a) { if (el.getAttribute && el.getAttribute(a)) s += '[' + a + '="' + el.getAttribute(a) + '"]'; });
    return s;
  }

  /* ------------------------------------------------------------------ *
   * 2. Clean a CLONE of the container (never touches the live page)
   * ------------------------------------------------------------------ */
  function absUrl(u, base) {
    if (!u) return '';
    u = u.trim();
    if (/^(javascript|vbscript):/i.test(u)) return '';
    try { return new URL(u, base).href; } catch (e) { return u; }
  }

  function pickImgSrc(img) {
    var src = img.getAttribute('src') || '';
    var lazy = img.getAttribute('data-src') || img.getAttribute('data-original') || img.getAttribute('data-lazy-src') || '';
    if ((!src || /^data:/i.test(src)) && lazy) src = lazy;
    if (!src) {
      var ss = img.getAttribute('srcset') || img.getAttribute('data-srcset') || '';
      if (ss) src = ss.split(',')[0].trim().split(/\s+/)[0];
    }
    return src;
  }

  function langFromNode(n) {
    if (!n || !n.getAttribute) return '';
    var v = n.getAttribute('data-code-language') || n.getAttribute('data-language') || n.getAttribute('data-lang') || '';
    if (!v) {
      var cls = n.getAttribute('class') || '';
      var m = cls.match(/(?:^|\s)(?:language|lang|highlight-source|highlight)-([\w+#.-]+)/i) || cls.match(/brush:\s*([\w+#.-]+)/i);
      if (m) v = m[1];
    }
    v = (v || '').toLowerCase().replace(/[^\w+#.-]/g, '');
    if (v === 'none' || v === 'nohighlight' || v === 'plaintext') v = '';
    return v;
  }

  var ADMON_TYPES = ['note', 'tip', 'warning', 'caution', 'important', 'sidebar'];
  function admonType(el) {
    var t = (el.getAttribute('data-type') || '').toLowerCase();
    if (ADMON_TYPES.indexOf(t) >= 0) return t;
    for (var i = 0; i < ADMON_TYPES.length; i++) if (el.classList && el.classList.contains(ADMON_TYPES[i])) return ADMON_TYPES[i];
    return 'note';
  }

  var SECTION_LEVEL = { part: 1, chapter: 1, preface: 1, appendix: 1, foreword: 1, introduction: 1, afterword: 1, conclusion: 1,
    glossary: 1, bibliography: 1, index: 1, colophon: 1, dedication: 1, acknowledgments: 1, sect1: 2, sect2: 3, sect3: 4, sect4: 5, sect5: 6 };

  function cleanContainer(el) {
    var doc = el.ownerDocument, base = doc.baseURI || doc.URL;
    var root = el.cloneNode(true);
    var c = cfg();
    function $$(sel) { return safeQueryAll(root, sel) || []; }
    function replaceTag(node, tag) {
      var n = doc.createElement(tag);
      while (node.firstChild) n.appendChild(node.firstChild);
      node.parentNode.replaceChild(n, node); return n;
    }

    // a) junk
    (c.removeSelectors || []).forEach(function (sel) { $$(sel).forEach(function (n) { if (n !== root && n.parentNode) n.parentNode.removeChild(n); }); });
    $$('[style]').forEach(function (n) { if (/display\s*:\s*none|visibility\s*:\s*hidden/i.test(n.getAttribute('style'))) n.parentNode && n.parentNode.removeChild(n); });
    $$('svg').forEach(function (n) { if (!n.closest('figure') && n.parentNode) n.parentNode.removeChild(n); });

    // b) URLs → absolute
    $$('a[href]').forEach(function (a) { var h = absUrl(a.getAttribute('href'), base); if (h) a.setAttribute('href', h); else a.removeAttribute('href'); });
    $$('img').forEach(function (img) {
      var s = absUrl(pickImgSrc(img), base);
      if (!s) { img.parentNode.removeChild(img); return; }
      img.setAttribute('src', s);
      ['srcset', 'data-src', 'data-srcset', 'data-original', 'data-lazy-src', 'loading', 'width', 'height', 'style'].forEach(function (a) { img.removeAttribute(a); });
    });
    // empty anchors (index terms, id targets)
    $$('a').forEach(function (a) { if (!norm(a.textContent) && !a.querySelector('img')) a.parentNode.removeChild(a); });

    // c) footnotes  (HTMLBook: a[data-type=noteref] → [data-type=footnote])
    var fnMap = {}, fnCount = 0;
    $$('[data-type="footnote"], aside[epub\\:type="footnote"], .footnote[id]').forEach(function (fn) {
      var id = fn.getAttribute('id');
      var back = fn.querySelector('sup a, a[href*="-marker"], a.footnote-backref');
      var label = back ? norm(back.textContent) : '';
      if (back) { var s = back.closest('sup') || back; if (fn.contains(s)) s.parentNode.removeChild(s); }
      label = (label || String(++fnCount)).replace(/[^\w-]/g, '') || String(++fnCount);
      if (id) fnMap[id] = label;
      fn.setAttribute('data-omd-footnote', label);
    });
    $$('a[data-type="noteref"], a[epub\\:type="noteref"], sup > a[href*="#"]').forEach(function (a) {
      var href = a.getAttribute('href') || '', id = href.split('#')[1] || '';
      var label = fnMap[id] || (a.getAttribute('data-type') === 'noteref' ? norm(a.textContent).replace(/[^\w-]/g, '') : '');
      if (!label) return;
      var host = a.parentNode && a.parentNode.tagName === 'SUP' && norm(a.parentNode.textContent) === norm(a.textContent) ? a.parentNode : a;
      var m = doc.createElement('span'); m.setAttribute('data-omd-noteref', label);
      m.textContent = label; host.parentNode.replaceChild(m, host);
    });

    // d) admonitions (note/tip/warning/sidebar) → marked blockquotes
    $$((c.admonitionSelectors || []).join(',')).forEach(function (box) {
      if (box.closest('[data-omd-admonition]') && box.closest('[data-omd-admonition]') !== box) { /* nested: still mark */ }
      var type = admonType(box), title = '';
      var h = box.querySelector(':scope > h1, :scope > h2, :scope > h3, :scope > h4, :scope > h5, :scope > h6, :scope > header, :scope > .title, :scope > p.title, :scope > .Heading');
      if (h) { title = norm(h.textContent); h.parentNode.removeChild(h); }
      if (!box.getAttribute('data-type') && !/\b(note|tip|warning|caution|important|sidebar)\b/.test(box.getAttribute('class') || '')) {
        // class-less boxes (e.g. Springer div.FormalPara): infer type from the title
        var tl = title.toLowerCase();
        type = /warn/.test(tl) ? 'warning' : /caution|danger/.test(tl) ? 'caution' : /tip|hint/.test(tl) ? 'tip' :
          /note/.test(tl) ? 'note' : /important/i.test(box.getAttribute('class') || '') && !title ? 'important' : 'note';
      }
      if (title.toLowerCase() === type) title = '';
      box.setAttribute('data-omd-admonition', type);
      if (title) box.setAttribute('data-omd-title', title);
    });

    // e0) Springer/Apress-style EPUB markup (O'Reilly hosts many Apress books): span-based emphasis
    $$('span.EmphasisTypeItalic, span.EmphasisTypeItalicUnderline, span.EmphasisTypeSmallCaps').forEach(function (n) { replaceTag(n, 'em'); });
    $$('span.EmphasisTypeBold, span.EmphasisTypeBoldItalic').forEach(function (n) { replaceTag(n, 'strong'); });
    $$('span.EmphasisFontCategoryNonProportional, span.literal, span.monospace').forEach(function (n) { if (!n.closest('pre, code')) replaceTag(n, 'code'); });

    // Springer list markup: <li><div class="ItemNumber">1.</div><div class="ItemContent">…  → drop duplicated number
    $$('li > .ItemNumber').forEach(function (n) { n.parentNode.removeChild(n); });
    // Springer citation entries: <div class="CitationNumber">[1]</div><div class="CitationContent">…</div> → one line
    $$('li.Citation > .CitationNumber, li.Citation > .CitationContent').forEach(function (n) { var sp = replaceTag(n, 'span'); sp.appendChild(doc.createTextNode(' ')); });
    // Springer context line (author · book · DOI): add separators between the spans
    $$('.ContextInformation > span').forEach(function (n) { if (n.nextSibling) n.parentNode.insertBefore(doc.createTextNode(' · '), n.nextSibling); });
    // Springer bibliography: numbers are already in the text ("[1] …") → use a bullet list
    $$('ol.BibliographyWrapper').forEach(function (ol) { replaceTag(ol, 'ul'); });
    // Citation refs: "1" → "[1]"
    $$('.CitationRef a, a[role="doc-biblioref"]').forEach(function (a) { var t = norm(a.textContent); if (/^\d+$/.test(t)) a.textContent = '[' + t + ']'; });
    // Tables that live on a separate page (Springer "ExternalTable"): keep caption + link, add a hint
    $$('div.ExternalTable').forEach(function (t) {
      var a = t.querySelector('a[href]'), p = doc.createElement('p'), b = doc.createElement('strong');
      var cap = t.querySelector('.Caption, .CaptionContent');
      b.textContent = spacedText(cap || t); p.appendChild(b);
      if (a) { p.appendChild(doc.createTextNode(' — 表格內容在另一頁 (table on separate page): ')); var l = doc.createElement('a'); l.setAttribute('href', a.getAttribute('href')); l.textContent = a.getAttribute('href'); p.appendChild(l); }
      t.parentNode.replaceChild(p, t);
    });

    // e) figures, examples, tables
    $$('figure, div[data-type="figure"], div.figure, div.Figure').forEach(function (fig) {
      var cap = fig.querySelector('figcaption, h6, h5, h4, .caption, .Caption, .figure-title, .FigureCaption');
      if (cap && !cap.querySelector('img')) {
        var p = doc.createElement('p'), em = doc.createElement('em');
        em.textContent = spacedText(cap); p.appendChild(em);
        cap.parentNode.removeChild(cap); fig.appendChild(p);
      }
    });
    $$('[data-type="example"]').forEach(function (ex) {
      var h = ex.querySelector(':scope > h1, :scope > h2, :scope > h3, :scope > h4, :scope > h5, :scope > h6');
      if (h) { var p = doc.createElement('p'), b = doc.createElement('strong'); b.textContent = norm(h.textContent); p.appendChild(b); h.parentNode.replaceChild(p, h); }
    });
    $$('table').forEach(function (t) {
      var cap = t.querySelector('caption');
      if (cap) { var p = doc.createElement('p'), b = doc.createElement('strong'); b.textContent = norm(cap.textContent); p.appendChild(b); t.parentNode.insertBefore(p, t); cap.parentNode.removeChild(cap); }
      $$('colgroup').forEach(function (cg) { if (t.contains(cg)) cg.parentNode.removeChild(cg); });
      var first = t.rows && t.rows[0];
      if (first && !t.querySelector('thead')) {
        Array.prototype.slice.call(first.cells).forEach(function (td) { if (td.tagName === 'TD') replaceTag(td, 'th'); });
        // move first row into a THEAD so the GFM plugin recognises it as header
        var thead = doc.createElement('thead'); first.parentNode.removeChild(first); thead.appendChild(first);
        t.insertBefore(thead, t.firstChild);
      }
      // nested tables / block content will be flattened by the cell rule
    });

    // f) definition lists & callout lists → bullet lists
    $$('dl').forEach(function (dl) {
      var ul = doc.createElement('ul'), isCallout = /callout/i.test(dl.getAttribute('class') || ''), li = null;
      Array.prototype.slice.call(dl.children).forEach(function (ch) {
        if (ch.tagName === 'DT') {
          li = doc.createElement('li'); var p = doc.createElement('p');
          if (isCallout) { p.textContent = '(' + (norm(ch.textContent) || (ch.querySelector('img') && ch.querySelector('img').getAttribute('alt')) || '?') + ')'; p.setAttribute('data-omd-callout', '1'); }
          else { var b = doc.createElement('strong'); while (ch.firstChild) b.appendChild(ch.firstChild); p.appendChild(b); }
          li.appendChild(p); ul.appendChild(li);
        } else if (ch.tagName === 'DD') {
          if (!li) { li = doc.createElement('li'); ul.appendChild(li); }
          var marker = li.querySelector('p[data-omd-callout]'), firstP = ch.querySelector('p');
          if (marker && li.children.length === 1) {
            // merge "(1)" with the explanation:  "(1) The build stage runs first."
            var target = firstP || ch;
            target.insertBefore(doc.createTextNode(marker.textContent + ' '), target.firstChild);
            marker.parentNode.removeChild(marker);
          }
          while (ch.firstChild) li.appendChild(ch.firstChild);
        }
      });
      dl.parentNode.replaceChild(ul, dl);
    });
    // callout markers inside code:  <a class="co"><img alt="1"></a>  → (1)
    $$('pre img').forEach(function (img) { img.parentNode.replaceChild(doc.createTextNode('(' + (img.getAttribute('alt') || '?') + ')'), img); });
    $$('pre br').forEach(function (br) { br.parentNode.replaceChild(doc.createTextNode('\n'), br); });

    // g) HTMLBook heading levels
    if (c.fixHtmlbookHeadings !== false) {
      $$('h1, h2, h3, h4, h5, h6').forEach(function (h) {
        var sec = h.closest('section[data-type], div[data-type^="sect"], div[data-type="chapter"]');
        if (!sec || !root.contains(sec) && sec !== root) return;
        var lvl = SECTION_LEVEL[(sec.getAttribute('data-type') || '').toLowerCase()];
        if (!lvl) return;
        var firstH = sec.querySelector('h1, h2, h3, h4, h5, h6');
        if (firstH !== h) return;
        if ('H' + lvl !== h.tagName) replaceTag(h, 'h' + lvl);
      });
    }
    return root;
  }

  /* ------------------------------------------------------------------ *
   * 3. Turndown configuration
   * ------------------------------------------------------------------ */
  function fenceFor(code) { var m = code.match(/`{3,}/g), n = 3; (m || []).forEach(function (s) { n = Math.max(n, s.length + 1); }); return new Array(n + 1).join('`'); }

  function makeTurndown() {
    var td = new TurndownService({ headingStyle: 'atx', hr: '---', bulletListMarker: '-', codeBlockStyle: 'fenced', emDelimiter: '*', strongDelimiter: '**', linkStyle: 'inlined' });
    var g = globalThis.turndownPluginGfm;
    if (g) td.use([g.tables, g.strikethrough, g.taskListItems]);
    td.remove(['script', 'style', 'noscript', 'template']);

    td.addRule('omdFencedCode', {
      filter: function (n) { return n.nodeName === 'PRE'; },
      replacement: function (content, n) {
        var code = n.querySelector('code');
        var lang = langFromNode(n) || langFromNode(code) || (n.parentNode && langFromNode(n.parentNode)) || '';
        var text = (n.textContent || '').replace(/\u00a0/g, ' ').replace(/\n+$/, '').replace(/^\n+/, '');
        var f = fenceFor(text);
        return '\n\n' + f + lang + '\n' + text + '\n' + f + '\n\n';
      }
    });
    td.addRule('omdInlineCode', {
      filter: function (n) { return n.nodeName === 'CODE' && !(n.parentNode && n.parentNode.nodeName === 'PRE') && !n.closest('pre'); },
      replacement: function (content, n) {
        var t = (n.textContent || '').replace(/\s*\n\s*/g, ' ');
        if (!t) return '';
        var max = 0; (t.match(/`+/g) || []).forEach(function (s) { max = Math.max(max, s.length); });
        var d = new Array(max + 2).join('`'), pad = /^`|`$/.test(t) || max ? ' ' : '';
        return d + pad + t + pad + d;
      }
    });
    // Lists: "- item" / "1. item" with child indentation equal to the marker width (CommonMark-friendly)
    td.addRule('omdListItem', {
      filter: 'li',
      replacement: function (content, node, options) {
        var parent = node.parentNode, prefix = options.bulletListMarker + ' ';
        if (parent && parent.nodeName === 'OL') {
          var start = parseInt(parent.getAttribute('start') || '1', 10) || 1;
          prefix = (start + Array.prototype.indexOf.call(parent.children, node)) + '. ';
        }
        var pad = new Array(prefix.length + 1).join(' ');
        content = content.replace(/^\n+/, '').replace(/\n+$/, '\n').replace(/\n/gm, '\n' + pad).replace(new RegExp('\n' + pad + '(?=\n)', 'g'), '\n');
        return prefix + content + (node.nextSibling && !/\n$/.test(content) ? '\n' : '');
      }
    });
    td.addRule('omdAdmonition', {
      filter: function (n) { return n.nodeType === 1 && n.hasAttribute('data-omd-admonition'); },
      replacement: function (content, n) {
        var type = n.getAttribute('data-omd-admonition'), title = n.getAttribute('data-omd-title') || '';
        var gh = { note: 'NOTE', tip: 'TIP', warning: 'WARNING', caution: 'CAUTION', important: 'IMPORTANT', sidebar: 'NOTE' }[type] || 'NOTE';
        var head;
        if (cfg().admonitionStyle === 'plain') head = '**' + (type.charAt(0).toUpperCase() + type.slice(1)) + (title ? ': ' + title : '') + '**';
        else head = '[!' + gh + ']' + (title ? '\n**' + title + '**\n' : '');
        var body = (head + '\n' + content.replace(/^\n+|\n+$/g, '')).replace(/\n{3,}/g, '\n\n');
        return '\n\n' + body.split('\n').map(function (l) { return l ? '> ' + l : '>'; }).join('\n') + '\n\n';
      }
    });
    td.addRule('omdNoteref', {
      filter: function (n) { return n.nodeType === 1 && n.hasAttribute('data-omd-noteref'); },
      replacement: function (c, n) { return '[^' + n.getAttribute('data-omd-noteref') + ']'; }
    });
    td.addRule('omdFootnote', {
      filter: function (n) { return n.nodeType === 1 && n.hasAttribute('data-omd-footnote'); },
      replacement: function (content, n) {
        var lines = content.replace(/^\s+|\s+$/g, '').split('\n');
        return '\n\n[^' + n.getAttribute('data-omd-footnote') + ']: ' + lines.map(function (l, i) { return i && l ? '    ' + l : l; }).join('\n') + '\n\n';
      }
    });
    td.addRule('omdTableCell', {
      filter: ['th', 'td'],
      replacement: function (content, n) {
        var t = content.replace(/^\s+|\s+$/g, '').replace(/\n+/g, '<br>').replace(/\|/g, '\\|');
        var idx = Array.prototype.indexOf.call(n.parentNode.childNodes, n);
        return (idx === 0 ? '| ' : ' ') + t + ' |';
      }
    });
    td.addRule('omdImage', {
      filter: 'img',
      replacement: function (c, n) {
        var src = n.getAttribute('src') || ''; if (!src) return '';
        var alt = (n.getAttribute('alt') || '').replace(/[\[\]\n]/g, ' ').trim();
        var title = n.getAttribute('title'); title = title ? ' "' + title.replace(/"/g, '\\"') + '"' : '';
        return '![' + alt + '](' + src.replace(/ /g, '%20').replace(/\)/g, '%29') + title + ')';
      }
    });
    return td;
  }

  /* ------------------------------------------------------------------ *
   * 4. Title / filename / front matter
   * ------------------------------------------------------------------ */
  function cleanDocTitle(t) {
    t = norm(t);
    t = t.replace(/\s*[-|–—]\s*O[’']Reilly.*$/i, '').replace(/\s*\[Book\]\s*$/i, '');
    return t;
  }
  function detectTitle(root, doc) {
    var h = root.querySelector('h1') || root.querySelector('h2');
    var t = h ? norm(h.textContent) : '';
    return t || cleanDocTitle(doc.title) || 'oreilly-page';
  }
  function sanitizeFilename(name, max) {
    max = max || cfg().maxFilenameLength || 120;
    var s = String(name || '')
      .replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ')
      .replace(/[\\/:*?"<>|]/g, ' ')          // Windows/macOS/Linux illegal
      .replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g, '') // zero-width / bidi
      .replace(/[~%#]/g, ' ')
      .replace(/\s+/g, ' ').trim()
      .replace(/^[.\s]+|[.\s]+$/g, '');
    var chars = Array.from(s); if (chars.length > max) s = chars.slice(0, max).join('').trim().replace(/[.\s]+$/, '');
    if (/^(con|prn|aux|nul|com\d|lpt\d)$/i.test(s)) s = '_' + s;
    return s || 'oreilly-page';
  }
  function frontMatter(meta) {
    if (cfg().frontMatter === false) return '';
    var q = function (s) { return JSON.stringify(String(s || '')); };
    return '---\n' +
      'title: ' + q(meta.title) + '\n' +
      'page_title: ' + q(meta.pageTitle) + '\n' +
      'source: ' + q(meta.url) + '\n' +
      'extracted_at: ' + q(meta.date) + '\n' +
      'generator: ' + q('oreilly-to-markdown v' + VERSION) + '\n' +
      '---\n\n';
  }
  function postProcess(md) {
    return md.replace(/^(#{1,6} [\d.]*\d)\\\./gm, '$1.')
      .replace(/(\S)\*\* \*\*(\S)/g, '$1 $2')        // "**a** **b**" → "**a b**"
      .replace(/^(>+)[ \u00a0\u2000-\u200a]+/gm, '$1 ')      // blockquote: single space after '>'
      .replace(/^[\u00a0\u2000-\u200a]+/gm, '')                  // stray NBSP / em-space at line start
  }

  function convert(doc) {
    doc = doc || document;
    var found = findContainer(doc);
    if (!found.el) return { ok: false, error: '找不到主要內容區塊 (no content container found)。請用「除錯」把 HTML 片段傳回來。', log: found.log };
    var root = cleanContainer(found.el);
    var title = detectTitle(root, found.el.ownerDocument);
    var td = makeTurndown();
    var body = postProcess(td.turndown(root));
    var meta = { title: title, pageTitle: norm(doc.title), url: doc.location ? doc.location.href : doc.URL, date: new Date().toISOString() };
    var md = frontMatter(meta) + body;
    var images = []; safeQueryAll(root, 'img').forEach(function (i) { var s = i.getAttribute('src'); if (s && images.indexOf(s) < 0) images.push(s); });
    return { ok: true, markdown: md, title: title, filename: sanitizeFilename(title), selector: found.selector, method: found.method,
      textLength: found.textLength, chars: md.length, images: images };
  }

  /* ------------------------------------------------------------------ *
   * 5. Images → zip  (fetched from the page context, user's own session)
   * ------------------------------------------------------------------ */
  var MIME_EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg', 'image/avif': 'avif', 'image/bmp': 'bmp' };
  function imageLocalName(url, idx, mime) {
    var base = 'image', ext = '';
    try { var p = new URL(url).pathname.split('/').pop() || ''; p = decodeURIComponent(p); var m = p.match(/^(.*?)(?:\.([a-z0-9]{2,5}))?$/i); base = m[1] || 'image'; ext = (m[2] || '').toLowerCase(); } catch (e) { }
    if (/^data:/i.test(url)) { base = 'inline'; var mm = url.match(/^data:([^;,]+)/i); if (mm) mime = mm[1]; }
    var mext = MIME_EXT[(mime || '').split(';')[0].trim().toLowerCase()];
    if (mext && (!ext || !/^(png|jpe?g|gif|webp|svg|avif|bmp)$/.test(ext))) ext = mext;
    if (!ext) ext = 'bin';
    base = sanitizeFilename(base, 60).replace(/\s+/g, '_') || 'image';
    var nn = String(idx + 1); while (nn.length < 2) nn = '0' + nn;
    return 'images/' + nn + '-' + base + '.' + ext;
  }
  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function bytesToBase64(u8) {
    var CH = 0x8000, parts = [];
    for (var i = 0; i < u8.length; i += CH) parts.push(String.fromCharCode.apply(null, u8.subarray(i, i + CH)));
    return btoa(parts.join(''));
  }

  async function buildZip(doc, opts) {
    opts = opts || {};
    var r = convert(doc); if (!r.ok) return r;
    if (!globalThis.fflate) return { ok: false, error: 'fflate (zip library) not loaded' };
    var files = {}, failed = [], md = r.markdown, enc = new TextEncoder();
    var fetchFn = opts.fetchImpl || fetch;
    for (var i = 0; i < r.images.length; i++) {
      var url = r.images[i];
      try {
        var res = await fetchFn(url, { credentials: 'include', cache: 'force-cache' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var buf = new Uint8Array(await res.arrayBuffer());
        var name = imageLocalName(url, i, res.headers && res.headers.get ? res.headers.get('content-type') : '');
        files[name] = buf;
        var mdUrl = url.replace(/ /g, '%20').replace(/\)/g, '%29');
        md = md.replace(new RegExp('\\]\\(' + escapeRe(mdUrl) + '(?=[ )])', 'g'), '](' + name);
      } catch (e) { failed.push({ url: url, error: String(e && e.message || e) }); }
    }
    if (failed.length) {
      md += '\n<!--\n以下圖片無法下載，保留原始網址 (images that could not be fetched; original URLs kept):\n' +
        failed.map(function (f) { return '- ' + f.url + '  (' + f.error + ')'; }).join('\n') + '\n-->\n';
    }
    files[r.filename + '.md'] = enc.encode(md);
    var zipped = globalThis.fflate.zipSync(files, { level: 6, mtime: new Date() });
    return { ok: true, title: r.title, filename: r.filename, selector: r.selector, method: r.method, chars: md.length,
      imageCount: r.images.length, imagesSaved: r.images.length - failed.length, failed: failed,
      zipBase64: bytesToBase64(zipped), zipBytes: zipped.length, markdown: opts.includeMarkdown ? md : undefined };
  }

  /* ------------------------------------------------------------------ *
   * 6. Debug report
   * ------------------------------------------------------------------ */
  function outline(el, depth, maxDepth, out) {
    if (!el || depth > maxDepth || out.length > 400) return;
    Array.prototype.forEach.call(el.children || [], function (ch) {
      if (/^(SCRIPT|STYLE|LINK|META|NOSCRIPT|SVG|PATH)$/i.test(ch.tagName)) return;
      var interesting = ch.id || ch.getAttribute('data-testid') || ch.getAttribute('data-type') || ch.getAttribute('role') || /^(MAIN|ARTICLE|SECTION|NAV|ASIDE|HEADER|FOOTER|IFRAME)$/.test(ch.tagName) || (ch.className && typeof ch.className === 'string');
      if (interesting) out.push(new Array(depth + 1).join('  ') + describe(ch) + '  (text:' + textLen(ch) + ')');
      outline(ch, depth + 1, maxDepth, out);
    });
  }
  function debugReport(doc) {
    doc = doc || document;
    var found = findContainer(doc), lines = [];
    lines.push('=== oreilly-to-markdown v' + VERSION + ' DEBUG ===');
    lines.push('URL: ' + doc.location.href);
    lines.push('document.title: ' + doc.title);
    lines.push('UserAgent: ' + navigator.userAgent);
    lines.push('Chosen: ' + (found.el ? describe(found.el) + '  via ' + found.method + ' [' + found.selector + ']  text:' + found.textLength : 'NONE'));
    lines.push('', '--- selector cascade ---');
    (found.log || []).forEach(function (l) { lines.push(JSON.stringify(l)); });
    var ifr = safeQueryAll(doc, 'iframe') || [];
    lines.push('', '--- iframes: ' + ifr.length + ' ---');
    ifr.slice(0, 10).forEach(function (f) { var so = false; try { so = !!f.contentDocument; } catch (e) { } lines.push(describe(f) + ' src=' + (f.getAttribute('src') || '') + ' sameOrigin=' + so); });
    lines.push('Shadow roots (open) on top-level elements: ' + (safeQueryAll(doc, '*') || []).filter(function (e) { return e.shadowRoot; }).length);
    var ol = []; outline(doc.body, 0, 7, ol);
    lines.push('', '--- page outline (depth<=7, max 400 lines) ---'); lines = lines.concat(ol);
    if (found.el) {
      var html = found.el.outerHTML, max = cfg().debugMaxHtmlChars || 15000;
      lines.push('', '--- chosen container outerHTML (first ' + Math.min(max, html.length) + ' of ' + html.length + ' chars) ---');
      lines.push(html.slice(0, max));
    }
    return lines.join('\n');
  }

  /* ------------------------------------------------------------------ *
   * 7. Clipboard + toast (page side, used by the context-menu path)
   * ------------------------------------------------------------------ */
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return 'clipboard-api'; } catch (e) { /* fall through */ }
    try {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
      (document.body || document.documentElement).appendChild(ta); ta.select();
      var ok = document.execCommand('copy'); ta.remove();
      if (ok) return 'execCommand';
    } catch (e2) { }
    return '';
  }
  function toast(msg, isError) {
    try {
      var old = document.getElementById('__omd_toast'); if (old) old.remove();
      var host = document.createElement('div'); host.id = '__omd_toast';
      host.style.cssText = 'position:fixed;z-index:2147483647;right:16px;bottom:16px;';
      var sr = host.attachShadow({ mode: 'closed' });
      var box = document.createElement('div');
      box.textContent = msg;
      box.style.cssText = 'font:14px/1.4 system-ui,"Noto Sans TC","Microsoft JhengHei",sans-serif;padding:10px 14px;border-radius:8px;color:#fff;max-width:420px;white-space:pre-wrap;box-shadow:0 4px 16px rgba(0,0,0,.3);background:' + (isError ? '#b00020' : '#1b5e20');
      sr.appendChild(box); (document.body || document.documentElement).appendChild(host);
      setTimeout(function () { host.remove(); }, isError ? 7000 : 3500);
    } catch (e) { }
  }

  /* ------------------------------------------------------------------ *
   * 8. Entry point called by popup / background
   *    mode: 'markdown' | 'debug' | 'zip'
   *    opts.copyInPage: copy result to clipboard from the page (context menu path)
   *    opts.toast: show an in-page toast
   * ------------------------------------------------------------------ */
  async function run(mode, opts) {
    opts = opts || {};
    try {
      if (mode === 'debug') {
        var text = debugReport(document), res = { ok: true, text: text, chars: text.length };
        if (opts.copyInPage) { res.copied = await copyText(text); if (opts.toast) toast(res.copied ? '已複製除錯資訊 (' + text.length + ' 字元)，請貼回給我們。' : '複製失敗，請改用工具列 popup 的除錯按鈕。', !res.copied); }
        return res;
      }
      if (mode === 'zip') {
        if (opts.toast) toast('正在下載圖片並打包 zip…');
        var z = await buildZip(document, opts);
        if (opts.toast) toast(z.ok ? '已打包：' + z.imagesSaved + '/' + z.imageCount + ' 張圖片' + (z.failed && z.failed.length ? '（' + z.failed.length + ' 張失敗，保留原網址）' : '') : '失敗：' + z.error, !z.ok);
        return z;
      }
      var r = convert(document);
      if (r.ok && opts.copyInPage) {
        r.copied = await copyText(r.markdown);
        if (opts.toast) toast(r.copied ? '已複製 Markdown（' + r.chars + ' 字元）\n標題：' + r.title : '自動複製失敗，請改用工具列 popup 的「複製」按鈕。', !r.copied);
      } else if (opts.toast) toast(r.ok ? '已轉換（' + r.chars + ' 字元），開始下載 .md' : r.error, !r.ok);
      if (opts.copyInPage) delete r.markdown; // no need to ship it back
      return r;
    } catch (e) {
      if (opts.toast) toast('轉換錯誤：' + (e && e.message || e), true);
      return { ok: false, error: String(e && e.stack || e) };
    }
  }

  globalThis.__OMD = { version: VERSION, run: run, convert: convert, buildZip: buildZip, findContainer: findContainer, cleanContainer: cleanContainer,
    debugReport: debugReport, sanitizeFilename: sanitizeFilename, imageLocalName: imageLocalName, toast: toast, describe: describe };
})();
