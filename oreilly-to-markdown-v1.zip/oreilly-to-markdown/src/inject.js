// Shared helpers for popup + background (ES module). No network access.
export const ORM_URL_RE = /^https:\/\/learning\.oreilly\.com\//i;
export const SCRIPT_FILES = [
  'vendor/turndown.js',
  'vendor/turndown-plugin-gfm.js',
  'vendor/fflate.min.js',
  'src/config.js',
  'src/converter.js'
];

export function isOreillyUrl(url) { return ORM_URL_RE.test(url || ''); }

/** Inject the converter into the active tab (top frame only) and run one mode. */
export async function runInTab(tabId, mode, opts = {}) {
  await chrome.scripting.executeScript({ target: { tabId }, files: SCRIPT_FILES });
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (m, o) => globalThis.__OMD.run(m, o),
    args: [mode, opts]
  });
  if (!res) throw new Error('No result from page');
  return res.result;
}

export async function toastInTab(tabId, msg, isError = false) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, func: (m, e) => globalThis.__OMD && globalThis.__OMD.toast(m, e), args: [msg, isError] });
  } catch (e) { /* ignore */ }
}

function safeName(name, ext) {
  const n = String(name || 'oreilly-page').replace(/[\\/:*?"<>|~%#\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim() || 'oreilly-page';
  return n + ext;
}

async function downloadUrl(url, filename) {
  try {
    return await chrome.downloads.download({ url, filename, conflictAction: 'uniquify', saveAs: false });
  } catch (e) {
    // Chrome rejected the filename (rare). Retry with a plain ASCII name.
    const ext = filename.slice(filename.lastIndexOf('.'));
    return await chrome.downloads.download({ url, filename: 'oreilly-page' + ext, conflictAction: 'uniquify', saveAs: false });
  }
}

export function downloadMarkdown(markdown, baseName) {
  const url = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(markdown);
  return downloadUrl(url, safeName(baseName, '.md'));
}

export function downloadZipBase64(b64, baseName) {
  return downloadUrl('data:application/zip;base64,' + b64, safeName(baseName, '.zip'));
}
