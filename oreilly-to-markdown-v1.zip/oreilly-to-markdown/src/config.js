/*
 * ============================================================================
 *  O'Reilly to Markdown — 使用者可調整設定 (USER CONFIG)
 * ============================================================================
 *  這個檔案是「唯一」需要調整選擇器的地方。修改後到 chrome://extensions
 *  按擴充功能卡片上的「重新載入 ↻」即可生效。
 *
 *  O'Reilly 的網頁結構(DOM)沒有經過實際登入驗證，所以這裡採用「選擇器瀑布」：
 *  由上往下逐一嘗試，第一個「找得到、且文字量 >= minTextLength」的元素
 *  就被當成主要內容區塊。全部失敗時，改用「最大文字區塊」啟發式演算法。
 *
 *  如果抓錯區塊：在 popup 點「除錯：複製 HTML 片段」，把剪貼簿內容貼回來給我們。
 * ============================================================================
 */
(function () {
  globalThis.__OMD_CONFIG = {
    // ---- 1. 主要內容區塊選擇器（依優先順序）------------------------------
    contentSelectors: [
      '#sbo-rt-content',                       // ✔ 已用真實頁面驗證 (2026-11, Apress 書籍章節)：書本內容容器
      '#book-content #sbo-rt-content',
      '[data-testid="contentViewer"]',
      '[data-testid="content-viewer"]',
      '.orm-ChapterReader-readerContainer',
      '[class*="ChapterReader"] [class*="content"]',
      '[class*="readerContainer"]',
      '#book-content',
      '#main article',                         // 真實頁面：main#main > section > article > … > #sbo-rt-content
      '[data-testid*="content"]',
      'main article',
      'article',
      '[role="main"]',
      'main',
      '#main'
    ],

    // 選擇器命中的元素至少要有這麼多字元，才算「真正的內容」
    minTextLength: 200,

    // 是否也搜尋「同網域」的 iframe（有些閱讀器把內容放在 iframe 裡）
    searchSameOriginIframes: true,

    // ---- 2. 內容區塊內要移除的雜訊 --------------------------------------
    removeSelectors: [
      'script', 'style', 'noscript', 'template', 'link', 'meta',
      'nav', '[role="navigation"]', '[role="toolbar"]', '[role="banner"]',
      '[role="search"]', '[role="dialog"]', '[role="tooltip"]',
      'button', 'input', 'select', 'textarea', 'form', 'label',
      'header[role="banner"]', 'footer',
      '[aria-hidden="true"]:not(img)', '[hidden]',
      'iframe', 'object', 'embed', 'video', 'audio', 'canvas',
      // O'Reilly 介面元件（猜測值，依實際 DOM 調整）
      '[class*="annotator"]', '[class*="Annotation"]', '[class*="annotation"]',
      '[class*="highlight-menu"]', '[class*="HighlightMenu"]',
      '[class*="toolbar"]', '[class*="Toolbar"]',
      '[class*="sidebar"]:not([data-type])', '[class*="Sidebar"]:not([data-type])',
      '[class*="breadcrumb"]', '[class*="Breadcrumb"]',
      '[class*="pagination"]', '[class*="Pagination"]',
      '[class*="next-prev"]', '[class*="NextPrev"]', '.t-sbo-prev', '.t-sbo-next', '.sbo-prev', '.sbo-next',
      '[class*="advert"]', '[class*="promo"]', '[class*="Promo"]', '.ad', '.ads',
      '[class*="share"]:not([data-type])', '[class*="social"]',
      '[data-testid*="toolbar"]', '[data-testid*="menu"]', '[data-testid*="banner"]',
      '[data-type="indexterm"]', 'a.indexterm',
      // 螢幕閱讀器專用的隱藏文字（例如 'Top of …'）、排版用空白 div
      '[class*="srOnly"]', '[class*="sr-only"]', '.visually-hidden', '.ClearBoth',
      '[role="doc-pagebreak"]'
    ],

    // ---- 3. 提示框 (note/tip/warning) → Markdown 引言區塊 -----------------
    // 'github'  : > [!NOTE]  (GitHub / Obsidian 會渲染成彩色提示框)
    // 'plain'   : > **Note**
    admonitionStyle: 'github',
    admonitionSelectors: [
      '[data-type="note"]', '[data-type="tip"]', '[data-type="warning"]',
      '[data-type="caution"]', '[data-type="important"]', '[data-type="sidebar"]',
      'aside.note', 'aside.tip', 'aside.warning', 'aside.caution', 'aside.sidebar',
      'div.note', 'div.tip', 'div.warning', 'div.caution', 'div.important',
      'div.FormalPara'                          // Springer/Apress 書籍的方框提示 (Note / Warning / Practitioner’s Note…)
    ],

    // ---- 4. 其他行為 ------------------------------------------------------
    // HTMLBook 格式常在每個 section 都用 <h1>；開啟後依 data-type (chapter/sect1/sect2…)
    // 自動修正為 # / ## / ### …
    fixHtmlbookHeadings: true,

    // Markdown 開頭加上 YAML front matter（標題、來源網址、擷取時間）
    frontMatter: true,

    // 除錯模式複製的 HTML 片段最大字元數
    debugMaxHtmlChars: 15000,

    // 檔名最大長度（字元）
    maxFilenameLength: 120
  };
})();
