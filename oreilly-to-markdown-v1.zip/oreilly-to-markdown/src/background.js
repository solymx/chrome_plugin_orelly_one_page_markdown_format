// Service worker: context-menu entries (only shown on learning.oreilly.com pages).
import { isOreillyUrl, runInTab, toastInTab, downloadMarkdown, downloadZipBase64 } from './inject.js';

const PATTERNS = ['https://learning.oreilly.com/*'];
const CONTEXTS = ['page', 'selection', 'link', 'image', 'frame'];
const MENU = [
  { id: 'omd-copy', title: '複製為 Markdown (Copy to clipboard)' },
  { id: 'omd-download', title: '下載 .md (Download .md)' },
  { id: 'omd-zip', title: '下載 .md + 圖片 zip (Download .md + images)' },
  { id: 'omd-debug', title: '除錯：複製 HTML 片段 (Debug snippet)' }
];

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'omd-root', title: "O'Reilly → Markdown", contexts: CONTEXTS, documentUrlPatterns: PATTERNS });
    for (const m of MENU) chrome.contextMenus.create({ ...m, parentId: 'omd-root', contexts: CONTEXTS, documentUrlPatterns: PATTERNS });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !tab.id) return;
  if (!isOreillyUrl(tab.url || info.pageUrl)) { console.warn('[omd] not an O\'Reilly page'); return; }
  try {
    if (info.menuItemId === 'omd-copy') {
      await runInTab(tab.id, 'markdown', { copyInPage: true, toast: true });
    } else if (info.menuItemId === 'omd-debug') {
      await runInTab(tab.id, 'debug', { copyInPage: true, toast: true });
    } else if (info.menuItemId === 'omd-download') {
      const r = await runInTab(tab.id, 'markdown', { toast: true });
      if (r && r.ok) await downloadMarkdown(r.markdown, r.filename);
    } else if (info.menuItemId === 'omd-zip') {
      const r = await runInTab(tab.id, 'zip', { toast: true });
      if (r && r.ok) await downloadZipBase64(r.zipBase64, r.filename);
    }
  } catch (e) {
    console.error('[omd]', e);
    await toastInTab(tab.id, '失敗：' + (e && e.message || e), true);
  }
});
