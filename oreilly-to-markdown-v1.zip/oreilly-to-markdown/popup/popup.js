import { isOreillyUrl, runInTab, downloadMarkdown, downloadZipBase64 } from '../src/inject.js';

const $ = (id) => document.getElementById(id);
const status = (msg, cls = '') => { const s = $('status'); s.textContent = msg; s.className = cls; };
const buttons = ['copy', 'download', 'zip'].map($);

async function copyFromPopup(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch (e) { /* fallback */ }
  const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
  const ok = document.execCommand('copy'); ta.remove(); return ok;
}

async function getTab() { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); return tab; }

async function act(kind) {
  const tab = await getTab();
  if (!tab || !isOreillyUrl(tab.url)) { status('這個頁面不是 learning.oreilly.com，無法轉換。', 'err'); return; }
  buttons.forEach((b) => (b.disabled = true));
  status(kind === 'zip' ? '轉換中，正在下載圖片並打包…' : '轉換中…');
  try {
    if (kind === 'debug') {
      const r = await runInTab(tab.id, 'debug');
      if (!r || !r.ok) throw new Error(r && r.error || 'unknown error');
      const ok = await copyFromPopup(r.text);
      status(ok ? `已複製除錯資訊（${r.chars} 字元）。請直接貼回給我們。` : '複製失敗。', ok ? 'ok' : 'err');
      return;
    }
    if (kind === 'zip') {
      const r = await runInTab(tab.id, 'zip');
      if (!r || !r.ok) throw new Error(r && r.error || 'unknown error');
      await downloadZipBase64(r.zipBase64, r.filename);
      let msg = `已下載 zip：${r.filename}.zip\n圖片 ${r.imagesSaved}/${r.imageCount} 張（${Math.round(r.zipBytes / 1024)} KB）`;
      if (r.failed.length) msg += `\n${r.failed.length} 張下載失敗，已保留原始網址（見 .md 最後的註解）。`;
      status(msg, r.failed.length ? 'err' : 'ok');
      return;
    }
    const r = await runInTab(tab.id, 'markdown');
    if (!r || !r.ok) throw new Error(r && r.error || 'unknown error');
    const info = `\n標題：${r.title}\n內容來源：${r.method === 'selector' ? r.selector : '自動偵測 (' + r.selector + ')'}`;
    if (kind === 'copy') {
      const ok = await copyFromPopup(r.markdown);
      status(ok ? `已複製 ${r.chars} 字元。${info}` : '複製失敗，請改用「下載 .md」。', ok ? 'ok' : 'err');
    } else {
      await downloadMarkdown(r.markdown, r.filename);
      status(`已下載：${r.filename}.md${info}`, 'ok');
    }
  } catch (e) {
    status('失敗：' + (e && e.message || e), 'err');
  } finally {
    buttons.forEach((b) => (b.disabled = false));
  }
}

$('copy').addEventListener('click', () => act('copy'));
$('download').addEventListener('click', () => act('download'));
$('zip').addEventListener('click', () => act('zip'));
$('debug').addEventListener('click', (e) => { e.preventDefault(); act('debug'); });

getTab().then((tab) => {
  if (!tab || !isOreillyUrl(tab.url)) {
    buttons.forEach((b) => (b.disabled = true));
    status('請先打開 learning.oreilly.com 的書本章節或文章頁面，再點這個按鈕。', 'err');
  }
});
